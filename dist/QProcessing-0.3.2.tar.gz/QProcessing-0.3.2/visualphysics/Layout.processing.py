def setup():
    fill(256, 256, 256)
    size(500, 500)
    rect(0, 0, 500, 500)
def draw():
    noLoop()
