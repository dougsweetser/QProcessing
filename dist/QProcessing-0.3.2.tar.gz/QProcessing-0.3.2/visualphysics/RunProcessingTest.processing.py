def setup():
    size(200, 400)
def draw():
    background(200)
