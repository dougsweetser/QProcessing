def setup():
    fill(256, 256, 256)
    size(720, 960)
    rect(0, 0, 720, 960)
    rectMode(CORNERS)
    fill(204, 102, 0)
    rect(0,600.0,720,960)
def draw():
    noLoop()
