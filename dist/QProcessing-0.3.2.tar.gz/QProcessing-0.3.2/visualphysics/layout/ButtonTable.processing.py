def setup():
    fill(256, 256, 256)
    size(320, 470)
    rect(0, 0, 320, 470)
    rectMode(CORNERS)
    fill(204, 102, 0)
    rect(1,311.0,319,470)
def draw():
    noLoop()
